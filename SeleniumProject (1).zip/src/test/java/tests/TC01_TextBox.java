
package tests;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

public class TC01_TextBox {
    WebDriver driver;

    @BeforeMethod
    public void setup(){
        driver = new ChromeDriver();
        driver.get("https://demoqa.com/text-box");
    }

    @Test
    public void testTextBox(){
        driver.findElement(By.id("userName")).sendKeys("Hazel");
        driver.findElement(By.id("userEmail")).sendKeys("hazel@example.com");
        driver.findElement(By.id("submit")).click();
    }

    @AfterMethod
    public void close(){
        driver.quit();
    }
}
